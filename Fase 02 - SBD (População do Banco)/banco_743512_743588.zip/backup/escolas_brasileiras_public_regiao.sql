INSERT INTO public.regiao (co_regiao, nome_regiao) VALUES (1, 'Norte');
INSERT INTO public.regiao (co_regiao, nome_regiao) VALUES (2, 'Nordeste');
INSERT INTO public.regiao (co_regiao, nome_regiao) VALUES (4, 'Sul');
INSERT INTO public.regiao (co_regiao, nome_regiao) VALUES (5, 'Centro-oeste');
INSERT INTO public.regiao (co_regiao, nome_regiao) VALUES (3, 'Sudeste');